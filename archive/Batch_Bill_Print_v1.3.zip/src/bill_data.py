"""
Data models for bill generation
"""
from dataclasses import dataclass
from typing import List


@dataclass
class CompanyInfo:
    """Company information for bill header"""
    name: str
    tax_id: str
    address: str
    phone: str
    branch_code: str = ""
    branch_address: str = ""


@dataclass
class Customer:
    """Customer information"""
    name: str
    address: str
    phone: str


@dataclass
class LineItem:
    """Single product line item"""
    description: str  # Product name + variant
    quantity: float
    unit_price: float
    total: float


@dataclass
class Invoice:
    """Complete invoice data"""
    invoice_number: str  # Tax invoice number (เลขที่ใบกำกับ)
    order_id: str  # Order number (หมายเลขคำสั่งซื้อ) 
    bill_number: str  # Internal bill number (เลขที่บิล) - format: 26XXXXX
    order_date: str
    tracking_number: str
    customer: Customer
    items: List[LineItem]
    subtotal: float
    discount: float
    shipping: float
    service_fee: float
    vat_rate: float
    grand_total: float
    
    def calculate_grand_total(self) -> float:
        """Calculate grand total: all item prices + shipping - discount"""
        return self.subtotal + self.shipping - self.discount

    def calculate_total_before_vat(self) -> float:
        """Calculate total before VAT: grand_total / 1.07"""
        return self.calculate_grand_total() / (1 + self.vat_rate)

    def calculate_vat(self) -> float:
        """Calculate VAT amount: before_vat * 7%"""
        return self.calculate_total_before_vat() * self.vat_rate
