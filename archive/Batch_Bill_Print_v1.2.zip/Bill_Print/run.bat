@echo off
chcp 65001 >nul 2>&1

echo ===========================
echo Starting Bill Print Webapp
echo ===========================
echo.
echo Server will start on http://localhost:5003
echo Your browser will open automatically...
echo.
echo Press Ctrl+C to stop the server
echo.

:: Try python first, then python3
python --version >nul 2>&1
if %ERRORLEVEL% neq 0 (
    python3 app.py
) else (
    python app.py
)

pause
