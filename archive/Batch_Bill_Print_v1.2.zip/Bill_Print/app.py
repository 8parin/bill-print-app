"""
Bill Print Flask Application
"""
import os
import json
from io import BytesIO
from flask import Flask, render_template, request, jsonify, send_file, url_for, make_response
from werkzeug.utils import secure_filename
import zipfile
from src.csv_parser import CSVParser
from src.pdf_generator_reportlab import PDFGeneratorReportLab as PDFGenerator
from src.bill_data import CompanyInfo

app = Flask(__name__)

# Load configuration
with open('config.json', 'r', encoding='utf-8') as f:
    config = json.load(f)

# Configuration - use absolute paths to avoid issues with send_file
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
app.config['UPLOAD_FOLDER'] = os.path.join(BASE_DIR, config['settings']['upload_folder'].lstrip('./'))
app.config['OUTPUT_FOLDER'] = os.path.join(BASE_DIR, config['settings']['output_folder'].lstrip('./'))
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Ensure directories exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['OUTPUT_FOLDER'], exist_ok=True)

# Global state
current_invoices = []
current_csv_path = None


def get_company_info():
    """Get company info from config"""
    c = config['company']
    return CompanyInfo(
        name=c['name'],
        tax_id=c['tax_id'],
        address=c['address'],
        phone=c['phone'],
        branch_code=c.get('branch_code', ''),
        branch_address=c.get('branch_address', '')
    )


@app.route('/')
def index():
    """Main page"""
    return render_template('index.html', company=config['company'])


@app.route('/upload', methods=['POST'])
def upload_csv():
    """Handle CSV upload"""
    global current_invoices, current_csv_path
    
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['file']
    
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    if not file.filename.endswith('.csv'):
        return jsonify({'error': 'File must be CSV'}), 400
    
    try:
        # Save file
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        current_csv_path = filepath
        
        # Detect columns
        parser = CSVParser(
            vat_rate=config['settings']['vat_rate'],
            custom_column_map=config.get('column_mapping')
        )
        detected_columns = parser.detect_columns(filepath)
        
        # Validate format (check if CSV structure matches expected format)
        df = parser.read_csv(filepath)
        format_valid, validation_result = parser.validate_csv_format(df)
        
        # Get column differences for detailed reporting
        column_diff = parser.get_column_differences(detected_columns)
        
        response_data = {
            'success': True,
            'filename': filename,
            'columns': detected_columns,
            'message': f'CSV uploaded successfully. {len(detected_columns)} columns detected.',
            'format_valid': format_valid,
            'validation': validation_result,
            'column_diff': column_diff
        }
        
        # If format has changed, warn the user
        if not format_valid:
            response_data['warning'] = True
            response_data['message'] = 'CSV uploaded, but format has changed. Please verify column mapping.'
        
        return jsonify(response_data)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/save-company', methods=['POST'])
def save_company():
    """Save company info to config"""
    try:
        data = request.get_json()
        config['company']['name'] = data.get('name', config['company']['name'])
        config['company']['tax_id'] = data.get('tax_id', config['company']['tax_id'])
        config['company']['address'] = data.get('address', config['company']['address'])
        config['company']['phone'] = data.get('phone', config['company']['phone'])

        with open('config.json', 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)

        return jsonify({'success': True, 'message': 'Company info saved.'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/get-field-definitions')
def get_field_definitions():
    """Get field definitions for mapping UI"""
    parser = CSVParser()
    return jsonify({
        'fields': parser.get_field_definitions(),
        'required_fields': parser.REQUIRED_FIELDS,
        'current_mapping': config.get('column_mapping', parser.COLUMN_MAP)
    })


@app.route('/save-mapping', methods=['POST'])
def save_mapping():
    """Save custom column mapping"""
    global current_invoices, current_csv_path
    
    try:
        mapping = request.json.get('mapping', {})
        
        # Validate mapping
        parser = CSVParser()
        valid, errors = parser.validate_mapping(mapping)
        
        if not valid:
            return jsonify({'error': 'Invalid mapping', 'details': errors}), 400
        
        # Save to config
        config['column_mapping'] = mapping
        with open('config.json', 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        
        # Parse CSV with new mapping
        # If current_csv_path is None (server restarted), find the most recent upload
        csv_path = current_csv_path
        if not csv_path:
            upload_dir = app.config['UPLOAD_FOLDER']
            csv_files = [f for f in os.listdir(upload_dir) if f.endswith('.csv')]
            if csv_files:
                # Use the most recently modified CSV
                csv_files.sort(key=lambda f: os.path.getmtime(os.path.join(upload_dir, f)), reverse=True)
                csv_path = os.path.join(upload_dir, csv_files[0])
                current_csv_path = csv_path

        if csv_path:
            parser_with_mapping = CSVParser(
                vat_rate=config['settings']['vat_rate'],
                custom_column_map=mapping
            )
            current_invoices = parser_with_mapping.parse_csv_to_invoices(csv_path)

            return jsonify({
                'success': True,
                'invoice_count': len(current_invoices),
                'message': f'Mapping saved! Found {len(current_invoices)} invoices.'
            })
        else:
            return jsonify({
                'success': True,
                'message': 'Mapping saved to config. Please upload a CSV file first.'
            })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/preview')
def preview_bill():
    """Preview first bill as HTML"""
    global current_invoices

    if not current_invoices:
        return jsonify({'error': 'No invoices loaded'}), 400

    try:
        # Get first invoice
        invoice = current_invoices[0]
        starting_bill_number = request.args.get('starting_bill_number', 2600001, type=int)
        invoice.bill_number = str(starting_bill_number)
        company = get_company_info()

        # Return rendered template
        return render_template('bill_template.html', invoice=invoice, company=company)

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/preview-by-order', methods=['POST'])
def preview_by_order():
    """Preview specific bill by order number"""
    global current_invoices
    
    if not current_invoices:
        return jsonify({'error': 'No invoices loaded'}), 400
    
    try:
        order_number = request.json.get('order_number', '').strip()
        
        if not order_number:
            return jsonify({'error': 'Order number is required'}), 400
        
        # Find invoice with matching order number OR tax invoice number
        matching_invoice = None
        for invoice in current_invoices:
            if (str(invoice.order_id) == str(order_number) or 
                str(invoice.invoice_number) == str(order_number)):
                matching_invoice = invoice
                break
        
        if not matching_invoice:
            return jsonify({'error': f'Order/Invoice number {order_number} not found'}), 404

        starting_bill_number = request.json.get('starting_bill_number', 2600001)
        matching_invoice.bill_number = str(starting_bill_number)

        company = get_company_info()
        html = render_template('bill_template.html', invoice=matching_invoice, company=company)
        
        return jsonify({
            'success': True,
            'html': html,
            'invoice_number': matching_invoice.invoice_number,
            'order_id': matching_invoice.order_id
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/generate', methods=['POST'])
def generate_bills():
    """Generate all PDFs"""
    global current_invoices
    
    if not current_invoices:
        return jsonify({'error': 'No invoices loaded'}), 400
    
    try:
        # Get paper settings from request
        data = request.get_json() or {}
        paper_size = data.get('paper_size', 'A5')
        orientation = data.get('orientation', 'portrait')
        starting_bill_number = data.get('starting_bill_number', 2600001)

        # Initialize PDF generator
        output_dir = app.config['OUTPUT_FOLDER']
        generator = PDFGenerator(output_dir)
        company = get_company_info()

        # Clean up old batch PDFs before generating new one
        for old_file in os.listdir(output_dir):
            if old_file.startswith('all_bills_') and old_file.endswith('.pdf'):
                os.remove(os.path.join(output_dir, old_file))

        # Generate all PDFs with paper settings and bill numbering
        output_files = generator.generate_batch_bills(current_invoices, company, paper_size, orientation, starting_bill_number)

        # Verify the generated files actually exist
        existing_files = [f for f in output_files if os.path.exists(f)]
        if not existing_files:
            return jsonify({'error': 'PDF generation failed - no output files created'}), 500

        return jsonify({
            'success': True,
            'count': len(existing_files),
            'files': [os.path.basename(f) for f in existing_files],
            'message': f'Successfully generated {len(existing_files)} bills ({paper_size} {orientation})'
        })

    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500


@app.route('/generate-one', methods=['POST'])
def generate_one_bill():
    """Generate single PDF (first invoice only)"""
    global current_invoices
    
    if not current_invoices:
        return jsonify({'error': 'No invoices loaded'}), 400
    
    try:
        # Get paper settings from request
        data = request.get_json() or {}
        paper_size = data.get('paper_size', 'A5')
        orientation = data.get('orientation', 'portrait')
        starting_bill_number = data.get('starting_bill_number', 2600001)
        
        # Initialize PDF generator
        output_dir = app.config['OUTPUT_FOLDER']
        generator = PDFGenerator(output_dir)
        company = get_company_info()
        
        # Assign bill number to first invoice
        current_invoices[0].bill_number = str(starting_bill_number)
        
        # Generate first invoice only with paper settings
        output_path = generator.generate_single_bill(current_invoices[0], company, paper_size, orientation)
        filename = os.path.basename(output_path)
        
        return jsonify({
            'success': True,
            'filename': filename,
            'invoice_number': current_invoices[0].invoice_number,
            'message': f'Successfully generated bill for invoice {current_invoices[0].invoice_number} ({paper_size} {orientation})'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/generate-by-order', methods=['POST'])
def generate_by_order():
    """Generate PDF for specific order number or tax invoice number"""
    global current_invoices
    
    if not current_invoices:
        return jsonify({'error': 'No invoices loaded'}), 400
    
    try:
        data = request.get_json() or {}
        order_number = data.get('order_number', '').strip()
        paper_size = data.get('paper_size', 'A5')
        orientation = data.get('orientation', 'portrait')
        starting_bill_number = data.get('starting_bill_number', 2600001)
        
        if not order_number:
            return jsonify({'error': 'Order number is required'}), 400
        
        # Find invoice with matching order number OR tax invoice number
        matching_invoice = None
        for invoice in current_invoices:
            if (str(invoice.order_id) == str(order_number) or 
                str(invoice.invoice_number) == str(order_number)):
                matching_invoice = invoice
                break
        
        if not matching_invoice:
            return jsonify({'error': f'Order/Invoice number {order_number} not found'}), 404
        
        # Initialize PDF generator
        output_dir = app.config['OUTPUT_FOLDER']
        generator = PDFGenerator(output_dir)
        company = get_company_info()
        
        # Assign bill number to this invoice
        matching_invoice.bill_number = str(starting_bill_number)
        
        # Generate bill with paper settings
        output_path = generator.generate_single_bill(matching_invoice, company, paper_size, orientation)
        filename = os.path.basename(output_path)
        
        return jsonify({
            'success': True,
            'filename': filename,
            'invoice_number': matching_invoice.invoice_number,
            'order_id': matching_invoice.order_id,
            'message': f'Successfully generated bill for order {matching_invoice.order_id} ({paper_size} {orientation})'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/download/<filename>')
def download_file(filename):
    """Download a single PDF"""
    filepath = os.path.join(app.config['OUTPUT_FOLDER'], filename)

    if not os.path.exists(filepath):
        return jsonify({'error': f'File not found: {filename}'}), 404

    with open(filepath, 'rb') as f:
        pdf_bytes = f.read()

    response = make_response(pdf_bytes)
    response.headers['Content-Type'] = 'application/pdf'
    response.headers['Content-Disposition'] = f'attachment; filename={filename}'
    response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '0'
    return response


@app.route('/download-all')
def download_all():
    """Download the batch-generated PDF file"""
    try:
        output_dir = app.config['OUTPUT_FOLDER']

        # Find the most recent all_bills PDF by modification time
        pdf_files = [f for f in os.listdir(output_dir) if f.startswith('all_bills_') and f.endswith('.pdf')]

        if not pdf_files:
            return jsonify({'error': 'No batch PDF found. Please generate bills first.'}), 404

        # Sort by modification time (newest first)
        pdf_files.sort(key=lambda f: os.path.getmtime(os.path.join(output_dir, f)), reverse=True)
        latest_pdf = pdf_files[0]
        filepath = os.path.join(output_dir, latest_pdf)

        # Read file bytes directly to bypass any caching
        with open(filepath, 'rb') as f:
            pdf_bytes = f.read()

        response = make_response(pdf_bytes)
        response.headers['Content-Type'] = 'application/pdf'
        response.headers['Content-Disposition'] = f'attachment; filename={latest_pdf}'
        response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
        response.headers['Pragma'] = 'no-cache'
        response.headers['Expires'] = '0'
        return response
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/stats')
def get_stats():
    """Get current statistics"""
    global current_invoices
    
    return jsonify({
        'invoice_count': len(current_invoices),
        'output_folder': app.config['OUTPUT_FOLDER']
    })


if __name__ == '__main__':
    # Auto-open browser
    import webbrowser
    import threading

    # Only open browser on first run, not on reloader restarts
    if os.environ.get('WERKZEUG_RUN_MAIN') != 'true':
        def open_browser():
            webbrowser.open('http://localhost:5003')
        threading.Timer(1.5, open_browser).start()

    # Run Flask
    app.run(debug=True, port=5003, host='0.0.0.0')
