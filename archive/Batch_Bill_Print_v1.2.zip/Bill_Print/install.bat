@echo off
chcp 65001 >nul 2>&1

echo ==================================
echo Bill Print Webapp - Installation
echo ==================================
echo.

:: Check Python version
echo Checking Python version...
python --version >nul 2>&1
if %ERRORLEVEL% neq 0 (
    python3 --version >nul 2>&1
    if %ERRORLEVEL% neq 0 (
        echo [ERROR] Python 3 is not installed
        echo Please install Python 3.8+ from https://www.python.org/downloads/
        echo Make sure to check "Add Python to PATH" during installation!
        pause
        exit /b 1
    )
    set PYTHON_CMD=python3
) else (
    set PYTHON_CMD=python
)

%PYTHON_CMD% --version
echo [OK] Python found
echo.

:: Check pip
echo Checking pip...
%PYTHON_CMD% -m pip --version >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo [ERROR] pip is not available
    echo Try: %PYTHON_CMD% -m ensurepip --upgrade
    pause
    exit /b 1
)
echo [OK] pip is available
echo.

:: Install dependencies
echo Installing Python dependencies...
echo This may take a few minutes...
echo.

%PYTHON_CMD% -m pip install --user -r requirements.txt

if %ERRORLEVEL% neq 0 (
    echo.
    echo [ERROR] Failed to install dependencies
    pause
    exit /b 1
)

echo.
echo [OK] Dependencies installed successfully
echo.

:: Create directories
echo Creating necessary directories...
if not exist "uploads" mkdir uploads
if not exist "output\bills" mkdir output\bills
echo [OK] Directories created
echo.

:: Create desktop shortcut
echo Creating desktop shortcut...
set DESKTOP=%USERPROFILE%\Desktop
set APP_PATH=%~dp0

(
echo @echo off
echo cd /d "%APP_PATH%"
echo call run.bat
) > "%DESKTOP%\BatchBill.bat"

echo [OK] Desktop shortcut created: %DESKTOP%\BatchBill.bat
echo.

echo ==================================
echo [OK] Installation Complete!
echo ==================================
echo.
echo To start the application:
echo   1. Double-click 'BatchBill.bat' on your Desktop
echo   2. Or run: run.bat
echo.
echo The webapp will open in your default browser at http://localhost:5003
echo.
pause
